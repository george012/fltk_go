#!/bin/bash
set -e

Config_file=./src/config/config.rs
ProductName=$(grep PROJECT_NAME ${Config_file} | awk -F '"' '{print $2}' | sed 's/\"//g')
REPO_PFEX=george012/$ProductName

Product_version_key="PROJECT_VERSION"

CURRENT_VERSION=$(grep ${Product_version_key} ${Config_file} | awk -F '"' '{print $2}' | sed 's/\"//g')

build_base_path=./build
UPLOAD_TMP_DIR=upload_tmp_dir

OS_TYPE="unknown"
get_os_type_with_rust(){
    uNames=$(uname -s)
    osName=${uNames: 0: 4}
    if [ "${osName}" == "Darw" ] # Darwin
    then
        OS_TYPE="macos"
    elif [ "${osName}" == "Linu" ] # Linux
    then
        OS_TYPE="linux"
    elif [ "${osName}" == "MING" ] # MINGW, windows, git-bash
    then
        OS_TYPE="windows"
    else
        OS_TYPE="unknown"
    fi
}
get_os_type_with_rust

function getCustomLib() {
  if [ -f "${CUSTOM_LIB_FILE}" ]; then
      rm -rf  ${CUSTOM_LIB_FILE}
  fi
  wget --no-check-certificate -O ${CUSTOM_LIB_FILE} https://raw.githubusercontent.com/george012/gtbox/latest/libs/gtgo/libgtgo.so && ldconfig
}

function preBuild() {
    echo "-----------pre-build configuration:------------Start--------------"
    echo "-----------build package:------------${ProductName}--------------"
    echo "-----------build version:------------${CURRENT_VERSION}----------"
    echo "-----------rustc version:------------$(rustc --version)---------------"

    mkdir -p ${build_base_path}/${BUILD_MODE}
    rm -rf ${build_base_path}/${BUILD_MODE}/*

    # rust 构建版本
    local build_rust_version=$(rustc --version)
    sed -i -e "s/\(const RUST_VERSION_BUILD: &str = \"\).*\(\";\)/\1${build_rust_version}\2/" ${Config_file}

    # rust 最小支持版本
    local min_rust_ver_no='rust_'$(grep rust-version ./Cargo.toml | awk -F '"' '{print $2}' | sed 's/\"//g')
    sed -i -e "s/\(const RUST_VERSION_SUPPORTED_MIN: &str = \"\).*\(\";\)/\1${min_rust_ver_no}\2/" ${Config_file}

    # 构建宿主系统
    sed -i -e "s/\(const PACKAGE_OS: &str = \"\).*\(\";\)/\1${OS_TYPE}\2/" ${Config_file}

    # 打包时间
    local package_time=$(date -u +%Y-%m-%d_%H:%M:%S_%Z)
    sed -i -e "s/\(const PACKAGE_TIME_UTC: &str = \"\).*\(\";\)/\1${package_time}\2/" ${Config_file}

    echo "-----------pre-build configuration:------------End----------------"
}

function build_windows() {
    echo "-----------build window---${BUILD_MODE}----------Start--------------"

    rustup target add x86_64-pc-windows-gnu

    local build_path=${build_base_path}/${BUILD_MODE}/${ProductName}_windows_x64
    mkdir -p ${build_path}

    if [[ "${BUILD_MODE}" == "release" ]]; then
        cargo build --target=x86_64-pc-windows-gnu --release
        cp ./target/x86_64-pc-windows-gnu/release/${ProductName}.exe ${build_path}
    else
        cargo build --target=x86_64-pc-windows-gnu
        cp ./target/x86_64-pc-windows-gnu/debug/${ProductName}.exe ${build_path}
    fi

    echo "-----------build window---${BUILD_MODE}----------End--------------"
}


function build_macos_universal() {
    echo "-----------build macos---${BUILD_MODE}----------Start--------------"

    rustup target add x86_64-apple-darwin
    rustup target add aarch64-apple-darwin

    build_path=${build_base_path}/${BUILD_MODE}/${ProductName}_mac_universal
    mkdir -p ${build_path}

    if [[ "${BUILD_MODE}" == "release" ]]; then
        cargo build --target=x86_64-apple-darwin --release
        cargo build --target=aarch64-apple-darwin --release

        lipo -create -output ${build_path}/${ProductName} \
            target/x86_64-apple-darwin/release/${ProductName} \
            target/aarch64-apple-darwin/release/${ProductName}
    else
        cargo build --target=x86_64-apple-darwin
        cargo build --target=aarch64-apple-darwin

        lipo -create -output ${build_path}/${ProductName} \
            target/x86_64-apple-darwin/debug/${ProductName} \
            target/aarch64-apple-darwin/debug/${ProductName}
    fi

    echo "-----------build macos---${BUILD_MODE}----------End--------------"

    package_macos_app "${build_path}"
}

function package_macos_app() {
    local build_path=$1
    echo "-----------create macOS app bundle----------Start--------------"

    local APP_NAME="${ProductName}"
    local EXECUTABLE_PATH="${build_path}/${ProductName}"
    local APP_DIR="${build_path}/${APP_NAME}.app"
    local CONTENTS_DIR="${APP_DIR}/Contents"
    local MACOS_DIR="${CONTENTS_DIR}/MacOS"
    local RESOURCES_DIR="${CONTENTS_DIR}/Resources"
    local PLIST_FILE="${CONTENTS_DIR}/Info.plist"
    local DMG_FILE="${build_path}/${APP_NAME}.dmg"
    local BUNDLE_ID=$(grep PROJECT_BUNDLE_ID ${Config_file} | awk -F '"' '{print $2}' | sed 's/\"//g')

    # 创建应用程序包目录结构
    mkdir -p "${MACOS_DIR}"
    mkdir -p "${RESOURCES_DIR}"

    # 复制可执行文件到应用程序包中
    mv "${EXECUTABLE_PATH}" "${MACOS_DIR}/${APP_NAME}"
    chmod a+x "${MACOS_DIR}/${APP_NAME}"

    # 创建 Info.plist 文件
    cat > "${PLIST_FILE}" <<EOL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>CFBundleIdentifier</key>
    <string>${BUNDLE_ID}</string>
    <key>CFBundleName</key>
    <string>${APP_NAME}</string>
    <key>CFBundleVersion</key>
    <string>${CURRENT_VERSION}</string>
    <key>CFBundleExecutable</key>
    <string>${APP_NAME}</string>
    <key>CFBundlePackageType</key>
    <string>APPL</string>
    <key>CFBundleIconFile</key>
    <string>AppIcon.icns</string>
</dict>
</plist>
EOL

    create_mac_resource "${build_path}"

    # 创建 DMG 文件
    hdiutil create -volname "${APP_NAME}" -srcfolder "${APP_DIR}" -ov -format UDZO "${DMG_FILE}"

    chmod a+x ${build_path}/${ProductName}.app

    xattr -r -d com.apple.quarantine ${build_path}/${ProductName}.app

    echo "Application package ${APP_DIR} and disk image ${DMG_FILE} have been created successfully."
    echo "-----------create macOS app bundle----------End--------------"
}

function create_mac_resource() {
    local build_path=$1
    echo "---------------------------------------------------------"
    echo "---------------------------------------------------------"
    echo "----------------------PWD  with ---$(PWD)----------------"
    echo "-----------build path with -------${build_path}----------"
    echo "---------------------------------------------------------"
    echo "---------------------------------------------------------"

    local app_icons=${build_path}/AppIcon.iconset
    mkdir -p ${app_icons}
    sips -z 16 16     ./Resources/icon.png --out ${app_icons}/icon_16x16.png
    sips -z 32 32     ./Resources/icon.png --out ${app_icons}/icon_16x16@2x.png
    sips -z 32 32     ./Resources/icon.png --out ${app_icons}/icon_32x32.png
    sips -z 64 64     ./Resources/icon.png --out ${app_icons}/icon_32x32@2x.png
    sips -z 128 128   ./Resources/icon.png --out ${app_icons}/icon_128x128.png
    sips -z 256 256   ./Resources/icon.png --out ${app_icons}/icon_128x128@2x.png
    sips -z 256 256   ./Resources/icon.png --out ${app_icons}/icon_256x256.png
    sips -z 512 512   ./Resources/icon.png --out ${app_icons}/icon_256x256@2x.png
    sips -z 512 512   ./Resources/icon.png --out ${app_icons}/icon_512x512.png
    sips -z 1024 1024 ./Resources/icon.png --out ${app_icons}/icon_512x512@2x.png

    iconutil -c icns ${app_icons} -o ${build_path}/AppIcon.icns

    rm -rf ${app_icons}

    mv ${build_path}/AppIcon.icns ${build_path}/${ProductName}.app/Contents/Resources/AppIcon.icns
}


function build_all_targets() {
    echo "-----------build mod------${BUILD_MODE}------Start--------------"
    # 构建打包模式
    formatted_str=$(echo "${BUILD_MODE}" | awk '{print toupper(substr($0,1,1)) tolower(substr($0,2))}')
    build_enum="rs_box::RunMode::RunMode${formatted_str}"
    sed -i -e "s/\(const BUILD_MODE: rs_box::RunMode = \).*\(;\)/\1${build_enum}\2/" ${Config_file}

    build_windows
    build_macos_universal

    echo "-----------build mod------${BUILD_MODE}------End--------------"

    # 恢复构建系统为本地调试状态
    local debug_mode="rs_box::RunMode::RunModeDebug"
    sed -i -e "s/\(const BUILD_MODE: rs_box::RunMode = \).*\(;\)/\1${debug_mode}\2/" ${Config_file}
    echo "-----------recover build mod-----default--with---${debug_mode}--------------------"


    if [[ $OS_TYPE == "macos" ]]; then
        echo "rm darwin build-cache"
        rm -rf ${Config_file}"-e"
    fi
}

function package_build_binary() {
    echo "-----------package build binary:------------Start--------------"

    cd ${build_base_path}/${BUILD_MODE} \
    && if [[ "${OS_TYPE}" == "windows" ]]; then
            7z a ./${ProductName}_${BUILD_MODE}_${CURRENT_VERSION}_mac_universal.zip ./${ProductName}_mac_universal >/dev/null 2>&1
            7z a ./${ProductName}_${BUILD_MODE}_${CURRENT_VERSION}_windows_x64.zip ./${ProductName}_windows_x64 >/dev/null 2>&1
        else
            zip -r ./${ProductName}_${BUILD_MODE}_${CURRENT_VERSION}_mac_universal.zip ./${ProductName}_mac_universal/${ProductName}.dmg
            zip -r ./${ProductName}_${BUILD_MODE}_${CURRENT_VERSION}_windows_x64.zip ./${ProductName}_windows_x64
        fi \
    && mkdir -p ../${UPLOAD_TMP_DIR} \
    && mv *.zip ../${UPLOAD_TMP_DIR} \
    && cd ../../
    echo "-----------package build binary:------------End----------------"
}

function handlerunMode() {
    if [[ "$1" == "release" || "$1" == "" ]]; then
        BUILD_MODE=release
    elif [[ "$1" == "test" ]]; then
        BUILD_MODE=test
    else
        echo "Usage: bash build.sh [release|test|debug], default is: release"
        exit 0
    fi
}
handlerunMode "$1"
preBuild
build_all_targets
package_build_binary
