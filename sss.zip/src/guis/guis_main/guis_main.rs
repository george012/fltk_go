use fltk::{app, button, prelude::*, window::Window};
use std::cell::RefCell;
use std::rc::Rc;
use std::sync::{Arc, Mutex};
use rand::Rng;
use crate::guis::gt_fltk_widges::gt_tableview::GTTableView;

pub fn load_guis_main(main_window: Rc<RefCell<Window>>) {
    // 获取窗口大小
    let (x, y, w, h) = {
        let win = main_window.borrow();
        (win.x(), win.y(), win.w(), win.h())
    };

    let space_scale = 5;

    // 创建 GTTableView 实例
    let table_view = Rc::new(RefCell::new(GTTableView::new(0 + space_scale, 45 + space_scale, w - space_scale * 2, h - space_scale * 2 - 45)));

    // 更新全部数据按钮
    let mut btn_update_all = button::Button::new(10, 10, 160, 30, "Update All Data");
    let table_view_clone = table_view.clone();
    btn_update_all.set_callback(move |_| {
        // 生成随机数据
        let mut rng = rand::thread_rng();
        let new_data: Vec<Vec<String>> = (0..5).map(|_| {
            (0..3).map(|_| format!("Random {}", rng.gen::<i32>())).collect()
        }).collect();
        table_view_clone.borrow().update_all(new_data);
    });

    // 更新单行数据按钮
    let mut btn_update_row = button::Button::new(180, 10, 160, 30, "Update Row");
    let table_view_clone = table_view.clone();
    let new_data_clone = table_view.borrow().data.clone();
    btn_update_row.set_callback(move |_| {
        let mut rng = rand::thread_rng();
        let mut new_data = new_data_clone.lock().unwrap();
        let random_row = rng.gen_range(0..new_data.len());
        let current_count: i32 = new_data[random_row][0].parse().unwrap_or(0);
        let updated_row = vec![
            (current_count + 1).to_string(),
            new_data[random_row][1].clone(),
            new_data[random_row][2].clone(),
        ];
        new_data[random_row] = updated_row.clone();
        table_view_clone.borrow().update_row(random_row, updated_row);
    });

    // 添加新数据按钮
    let mut btn_add_data = button::Button::new(350, 10, 160, 30, "Add Data");
    let table_view_clone = table_view.clone();
    btn_add_data.set_callback(move |_| {
        // 生成一行随机数据
        let mut rng = rand::thread_rng();
        let new_row: Vec<String> = (0..3).map(|_| format!("Random {}", rng.gen::<i32>())).collect();
        table_view_clone.borrow().add(new_row);
    });

    // 删除数据按钮
    let mut btn_del_data = button::Button::new(520, 10, 160, 30, "Delete Data");
    let table_view_clone = table_view.clone();
    btn_del_data.set_callback(move |_| {
        let mut rng = rand::thread_rng();
        let row_to_delete = rng.gen_range(0..table_view_clone.borrow().data.lock().unwrap().len());
        table_view_clone.borrow().del(row_to_delete);
    });

    // 将表格和按钮添加到窗口中
    main_window.borrow_mut().add(&btn_update_row);
    main_window.borrow_mut().add(&btn_update_all);
    main_window.borrow_mut().add(&btn_add_data);
    main_window.borrow_mut().add(&btn_del_data);

    // 解锁并添加 table_view
    let a_tb = table_view.borrow().table_view.clone();
    main_window.borrow_mut().add(&*a_tb.lock().unwrap());
}
