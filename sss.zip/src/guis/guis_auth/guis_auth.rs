use fltk::{prelude::*, *};
use crate::config;
use crate::guis::gt_fltk_widges::{self, gt_button::GtFltkButton};

use std::rc::Rc;
use std::cell::RefCell;

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum AuthActionType {
    AuthActionNone,
    AuthActionLogin,
    AuthActionRegister,
    AuthActionForgetPassword,
}

impl AuthActionType {
    pub fn get_locales_key(&self) -> &str {
        match self {
            AuthActionType::AuthActionLogin => "login",
            AuthActionType::AuthActionRegister => "register",
            AuthActionType::AuthActionForgetPassword => "forget_password",
            _ => "none",
        }
    }
}

pub fn get_auth_type_with_locales_str(locales_key: &str) -> AuthActionType {
    match locales_key {
        "login" => AuthActionType::AuthActionLogin,
        "register" => AuthActionType::AuthActionRegister,
        "forget_password" => AuthActionType::AuthActionForgetPassword,
        _ => AuthActionType::AuthActionNone,
    }
}

fn create_button(caption: &str) -> button::Button {
    let mut btn = button::Button::default().with_label(caption);
    btn.set_color(enums::Color::from_rgb(225, 225, 225));
    btn
}

fn buttons_panel<F: FnMut(AuthActionType) + 'static>(parent: &mut group::Flex, callback: F) {
    let callback = Rc::new(RefCell::new(callback));

    frame::Frame::default();
    let w = frame::Frame::default().with_label("Welcome to Flex Login");

    let mut urow = group::Flex::default().row();
    {
        frame::Frame::default()
            .with_label("Username:")
            .with_align(enums::Align::Inside | enums::Align::Right);
        let username = input::Input::default();

        urow.fixed(&username, 180);
        urow.end();
    }

    let mut prow = group::Flex::default().row();
    {
        frame::Frame::default()
            .with_label("Password:")
            .with_align(enums::Align::Inside | enums::Align::Right);
        let password = input::Input::default();

        prow.fixed(&password, 180);
        prow.end();
    }

    let pad = frame::Frame::default();

    let mut brow = group::Flex::default().row();
    {
        frame::Frame::default();

        let mut reg_btn = gt_fltk_widges::gt_button::GtFltkButton::default()
            .with_label("Register");
        reg_btn.set_tag(AuthActionType::AuthActionRegister.get_locales_key());

        let reg_btn_tag = reg_btn.tag;  // 在设置回调前获取 tag
        let callback_clone = Rc::clone(&callback);
        reg_btn.set_callback(move |_| {
            callback_clone.borrow_mut()(get_auth_type_with_locales_str(reg_btn_tag));
        });

        let mut login_btn = gt_fltk_widges::gt_button::GtFltkButton::default()
            .with_label("Login");
        login_btn.set_tag(AuthActionType::AuthActionLogin.get_locales_key());

        let login_btn_tag = login_btn.tag;  // 在设置回调前获取 tag
        let callback_clone = Rc::clone(&callback);
        login_btn.set_callback(move |_| {
            callback_clone.borrow_mut()(get_auth_type_with_locales_str(login_btn_tag));
        });

        brow.fixed(&reg_btn.fltk_button, 80);
        brow.fixed(&login_btn.fltk_button, 80);
        brow.end();
    }

    let b = frame::Frame::default();

    frame::Frame::default();

    parent.fixed(&w, 60);
    parent.fixed(&urow, 30);
    parent.fixed(&prow, 30);
    parent.fixed(&pad, 1);
    parent.fixed(&brow, 30);
    parent.fixed(&b, 30);
}

fn middle_panel<F: FnMut(AuthActionType) + 'static>(parent: &mut group::Flex, callback: F) {
    frame::Frame::default();

    let mut frame = frame::Frame::default().with_label("Image");
    frame.set_frame(enums::FrameType::BorderBox);
    frame.set_color(enums::Color::from_rgb(0, 200, 0));
    let spacer = frame::Frame::default();

    let mut bp = group::Flex::default().column();
    buttons_panel(&mut bp, callback);
    bp.end();

    frame::Frame::default();

    parent.fixed(&frame, 200);
    parent.fixed(&spacer, 10);
    parent.fixed(&bp, 300);
}

pub fn load_guis_auth<F: FnMut(AuthActionType) + 'static>(main_window: &mut window::Window, callback: F)
    where
        F: FnMut(AuthActionType) + 'static
{
    let mut parent = group::Flex::default_fill().column();
    frame::Frame::default();

    let mut mp = group::Flex::default().row();
    middle_panel(&mut mp, callback);
    mp.end();

    frame::Frame::default();

    parent.fixed(&mp, 200);
}
