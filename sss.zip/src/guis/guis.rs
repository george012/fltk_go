use std::sync::{Arc, atomic::AtomicBool, Mutex};
use std::thread;

use fltk::{*, prelude::*};
use lazy_static::lazy_static;
use crate::config;
use crate::guis;
use guis::guis_auth::guis_auth;
use guis::guis_main::guis_main;
use guis::guis_switch_language::guis_switch_language;
use std::rc::Rc;
use std::cell::RefCell;


pub fn load_guis(main_window: Rc<RefCell<fltk::window::Window>>) {
    guis_switch_language::load_guis_switch_language(&mut *main_window.borrow_mut(), |language| {
        rs_box::rs_box_log::rs_box_log::log_info(&format!("{} {}", config::locales::get_locales_value("action.choice", language), language.language_value()));
    });

    let main_window_clone = main_window.clone();

    guis_auth::load_guis_auth(&mut *main_window.borrow_mut(), move |auth_action_type| {
        if auth_action_type == guis_auth::AuthActionType::AuthActionRegister {
            rs_box::rs_box_log::rs_box_log::log_info("点击注册");
        } else if auth_action_type == guis_auth::AuthActionType::AuthActionLogin {
            rs_box::rs_box_log::rs_box_log::log_info("点击登录");
            // 进行页面更换
            handle_login(main_window_clone.clone());
        }
    });
}

fn handle_login(main_window: Rc<RefCell<fltk::window::Window>>) {
    rs_box::rs_box_log::rs_box_log::log_info("点击登录");
    // 进行页面更换
    main_window.borrow_mut().clear(); // 清除当前窗口内容

    guis_main::load_guis_main(main_window.clone()); // 加载主页面内容

    main_window.borrow_mut().redraw(); // 重绘窗口
}



