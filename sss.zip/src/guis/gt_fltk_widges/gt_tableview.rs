use fltk::{
    app,
    enums::{Align, Color, FrameType},
    prelude::*,
    table::{TableRow, TableContext},
};
use std::sync::{Arc, Mutex};
use std::thread;

pub struct GTTableView {
    pub table_view: Arc<Mutex<TableRow>>,
    pub data: Arc<Mutex<Vec<Vec<String>>>>, // 二维数组存储表格数据
}

impl GTTableView {
    pub fn new(x: i32, y: i32, w: i32, h: i32) -> Self {
        let data = Arc::new(Mutex::new(Vec::<Vec<String>>::new()));
        let data_clone = Arc::clone(&data);
        let table = Arc::new(Mutex::new(TableRow::new(x, y, w, h, "")));

        {
            let mut table = table.lock().unwrap();
            table.set_rows(0);
            table.set_row_header(false);
            table.set_cols(3);
            table.set_col_header(true);
            table.set_tab_cell_nav(true);
            table.end();
        }

        table.lock().unwrap().draw_cell(Box::new(move |t: &mut TableRow, ctx: TableContext, row: i32, col: i32, x: i32, y: i32, w: i32, h: i32| {
            match ctx {
                TableContext::StartPage => {},
                TableContext::ColHeader => {
                    draw_header(&format!("Col {}", col + 1), x, y, w, h);
                },
                TableContext::Cell => {
                    let selected = t.is_selected(row, col);
                    let data = data_clone.lock().unwrap();
                    let txt = if let Some(row_data) = data.get(row as usize) {
                        if let Some(cell_data) = row_data.get(col as usize) {
                            format!("{}", cell_data)
                        } else {
                            format!("{}{}", row, col)
                        }
                    } else {
                        format!("{}{}", row, col)
                    };
                    draw_data(&txt, x, y, w, h, selected);
                },
                _ => {}
            }
        }));

        GTTableView { table_view: table, data }
    }

    pub fn update_all(&self, new_data: Vec<Vec<String>>) {
        let data_clone = self.data.clone();
        let table_clone = self.table_view.clone();
        let len = new_data.len();
        thread::spawn(move || {
            {
                let mut data = data_clone.lock().unwrap();
                *data = new_data;
            }
            app::awake_callback(move || {
                let mut table = table_clone.lock().unwrap();
                table.set_rows(len as i32);
                table.redraw();
            });
        });
    }

    pub fn update_row(&self, row: usize, new_values: Vec<String>) {
        let data_clone = self.data.clone();
        let table_clone = self.table_view.clone();
        thread::spawn(move || {
            {
                let mut data = data_clone.lock().unwrap();
                if row < data.len() {
                    data[row] = new_values;
                }
            }
            app::awake_callback(move || {
                let mut table = table_clone.lock().unwrap();
                table.redraw();
            });
        });
    }

    pub fn add(&self, new_values: Vec<String>) {
        let data_clone = self.data.clone();
        let table_clone = self.table_view.clone();
        thread::spawn(move || {
            {
                let mut data = data_clone.lock().unwrap();
                data.push(new_values);
            }
            app::awake_callback(move || {
                let mut table = table_clone.lock().unwrap();
                let rows = table.rows();
                table.set_rows(rows + 1);
                table.redraw();
            });
        });
    }

    pub fn del(&self, row: usize) {
        let data_clone = self.data.clone();
        let table_clone = self.table_view.clone();
        thread::spawn(move || {
            {
                let mut data = data_clone.lock().unwrap();
                if row < data.len() {
                    data.remove(row);
                }
            }
            app::awake_callback(move || {
                let mut table = table_clone.lock().unwrap();
                let rows = table.rows();
                table.set_rows(rows - 1);
                table.redraw();
            });
        });
    }
}

fn draw_header(txt: &str, x: i32, y: i32, w: i32, h: i32) {
    fltk::draw::push_clip(x, y, w, h);
    fltk::draw::draw_box(
        FrameType::ThinUpBox,
        x,
        y,
        w,
        h,
        Color::FrameDefault,
    );
    fltk::draw::set_draw_color(Color::Black);
    fltk::draw::set_font(fltk::enums::Font::Helvetica, 14);
    fltk::draw::draw_text2(txt, x, y, w, h, Align::Center);
    fltk::draw::pop_clip();
}

fn draw_data(txt: &str, x: i32, y: i32, w: i32, h: i32, selected: bool) {
    fltk::draw::push_clip(x, y, w, h);
    if selected {
        fltk::draw::set_draw_color(Color::from_u32(0x00D3_D3D3));
    } else {
        fltk::draw::set_draw_color(Color::White);
    }
    fltk::draw::draw_rectf(x, y, w, h);
    fltk::draw::set_draw_color(Color::Gray0);
    fltk::draw::set_font(fltk::enums::Font::Helvetica, 14);
    fltk::draw::draw_text2(txt, x, y, w, h, Align::Center);
    fltk::draw::draw_rect(x, y, w, h);
    fltk::draw::pop_clip();
}
