use fltk::{
    prelude::*,
    button::Button,
    enums::Color,
};

pub struct GtFltkButton {
    pub fltk_button: Button,
    pub tag: &'static str,
}

// 使用 widget_extends! 宏继承和扩展 Button 的特性
fltk::widget_extends!(GtFltkButton, Button, fltk_button);

impl GtFltkButton {
    pub fn default() -> Self {
        let btn = Button::default();
        GtFltkButton { fltk_button: btn, tag: "" }
    }

    // 创建一个新的 GtFltkButton 实例
    pub fn new(x: i32, y: i32, width: i32, height: i32, text: &str) -> Self {
        let btn = Button::new(x, y, width, height, text);
        GtFltkButton { fltk_button: btn, tag: "" }
    }

    pub fn set_callback<F: FnMut(&mut GtFltkButton) + 'static>(&mut self, mut callback: F) {
        let btn_ptr = self as *mut GtFltkButton;
        self.fltk_button.set_callback(move |_| {
            unsafe {
                if let Some(btn) = btn_ptr.as_mut() {
                    callback(btn);
                }
            }
        });
    }

    pub fn set_tag(&mut self, tag_str: &'static str) {
        self.tag = tag_str;
    }
}
