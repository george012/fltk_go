use fltk::{app, button, window};
use fltk::prelude::{ButtonExt, GroupExt, WidgetBase, WidgetExt};
use guis::gt_fltk_widges::gt_tableview::GTTableView; // 确保这里的模块路径正确
use std::sync::{Arc, Mutex};
use rand::Rng;
use crate::guis;

#[test]
fn test_gt_tableview() {
    let app = app::App::default();
    let mut win = window::Window::new(100, 100, 800, 600, "GTTableView Test");

    let new_data = Arc::new(Mutex::new(vec![
        vec!["1".to_string(), "New 2".to_string(), "New 3".to_string()],
        vec!["1".to_string(), "New 5".to_string(), "New 6".to_string()],
        vec!["1".to_string(), "New 8".to_string(), "New 9".to_string()],
        vec!["1".to_string(), "New 11".to_string(), "New 12".to_string()],
        vec!["1".to_string(), "New 14".to_string(), "New 15".to_string()],
    ]));

    let table_view = GTTableView::new(10, 50, 780, 580);

    // 更新一行的按钮
    let mut btn_update_row = button::Button::new(10, 10, 160, 30, "Update Row");
    let table_view_clone = table_view.clone();
    let new_data_clone = new_data.clone();
    btn_update_row.set_callback(move |_| {
        let mut table_view = table_view_clone.clone();
        let mut data = new_data_clone.lock().unwrap();
        let mut rng = rand::thread_rng();
        let random_row = rng.gen_range(0..data.len());
        let current_count: i32 = data[random_row][0].parse().unwrap_or(0);
        data[random_row][0] = (current_count + 1).to_string();
        let updated_row = vec![
            data[random_row][0].clone(),
            data[random_row][1].clone(),
            data[random_row][2].clone(),
        ];
        table_view.update_row(random_row, updated_row);
    });

    // 更新所有数据的按钮
    let mut btn_update_all = button::Button::new(180, 10, 160, 30, "Update All Data");
    let table_view_clone = table_view.clone();
    let new_data_clone = new_data.clone();
    btn_update_all.set_callback(move |_| {
        let mut data = new_data_clone.lock().unwrap();
        for row in &mut *data {
            let current_count: i32 = row[0].parse().unwrap_or(0);
            row[0] = (current_count + 1).to_string();
        }
        let table_view = table_view_clone.clone();
        table_view.update_data_all(data.clone());
    });

    win.end();
    win.show();
    app.run().unwrap();
}
