use fltk::{prelude::*, *};
use crate::config;

pub fn load_guis_switch_language<F: FnMut(config::locales::Language) + 'static>(main_window: &mut fltk::window::Window, mut callback: F){
    let mut choice = menu::Choice::default()
        .with_size(120, 30)
        .center_of_parent()
        .with_label("Select item");

    choice.set_pos(main_window.width() - choice.width() - 10,10);

    let a_langs = config::locales::get_supported_languages();
    let default_language = config::locales::DEFAULT_LANGUAGE.lock().unwrap();

    let mut default_index = 0;  // 默认索引为0，以防未找到匹配项

    for (index, lang_val) in a_langs.iter().enumerate() {
        choice.add_choice(lang_val.language_value().as_str());
        // 检查当前添加的语言是否为默认语言
        if *lang_val == *default_language {
            default_index = index;  // 更新默认语言的索引
        }
    }

    choice.set_value(default_index as i32);  // 设置默认语言选项

    choice.set_callback(move |c| {
        let idx = c.value() as usize; // 转换索引为usize
        if let Some(lang) = a_langs.get(idx) {
            callback(*lang); // 调用传入的回调函数
        }
    });
}