use std::sync::{Mutex};
use lazy_static::lazy_static;
use rust_i18n::t;
use std::collections::HashMap;

rust_i18n::i18n!("locales");

lazy_static! {
    #[derive(Debug, Clone, Copy,PartialEq)]
    pub static ref DEFAULT_LANGUAGE: Mutex<Language> = Mutex::new(Language::EnUs);

    static ref SUPPORRTED_LANGUAGES: Mutex<Vec<Language>> = Mutex::new(vec![
        Language::EnUs,
        Language::ZhHK,
        Language::ZhCN,
    ]);
}
#[derive(Debug, Clone, Copy,PartialEq)]
pub enum Language {
    EnUs,
    ZhHK,
    ZhCN,
}
impl Language {
    pub fn language_key(&self) -> &str {
        match self {
            Language::EnUs => "en-US",
            Language::ZhHK => "zh-HK",
            Language::ZhCN => "zh-CN",
        }
    }
    pub fn language_value(&self) -> String {
        match self {
            Language::EnUs => get_locales_value("language_title", Language::EnUs),
            Language::ZhHK => get_locales_value("language_title", Language::ZhHK),
            Language::ZhCN => get_locales_value("language_title", Language::ZhCN),
        }
    }
}

pub fn get_supported_languages() -> Vec<Language> {
    // 直接访问并克隆全局 Mutex 中的 HashMap
     SUPPORRTED_LANGUAGES.lock().unwrap().clone()
}

pub fn get_locales_value(locales_key: &str, language: Language) -> String {
    let lang_key = language.language_key();

   t!(locales_key, locale = lang_key).to_string()
}