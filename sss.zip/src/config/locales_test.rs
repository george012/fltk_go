#[cfg(test)]
mod tests {
    use std::fmt::format;
    use super::super::locales; // 导入 math 模块中的函数

    #[test]
    fn test_supported_languages() {

        let mut a_langs = locales::get_supported_languages();
        for a_lang_val in a_langs {
            rs_box::rs_box_log::rs_box_log::log_info(&format!("supported languages: {}",a_lang_val.language_value()))
        }
    }

    #[test]
    fn test_get(){
        let a_lang = locales::get_locales_value("language_title",super::super::locales::Language::ZhCN);

        println!("language str with : {}",a_lang);

        let b_lang = locales::get_locales_value("language_title",super::super::locales::Language::ZhHK);
        println!("language str with : {}",b_lang);

        let c_lang = locales::get_locales_value("language_title",super::super::locales::Language::EnUs);
        println!("language str with : {}",c_lang);

    }
}