use rs_box;
use std::sync::Mutex;
use lazy_static::lazy_static;

lazy_static! {
    pub static ref DEFAULT_APP: Mutex<App> = Mutex::new(App::default());
}

#[derive(PartialEq)]
pub struct App {
    pub name: String,
    pub bundle_id: String,
    pub version: String,
    pub description: String,
    pub run_mode: rs_box::RunMode,
    pub git_commit_hash: String,
    pub git_commit_time_utc: String,
    pub rust_version_build: String,
    pub rust_version_supported_min: String,
    pub package_os: String,
    pub package_time_utc: String,
    pub local_db_path: String,
    pub log_dir: String,
}

impl App {
    fn default() -> Self {
        Self {
            name: "".to_string(),
            bundle_id: "".to_string(),
            version: "".to_string(),
            description: "".to_string(),
            run_mode: rs_box::RunMode::RunModeDebug,  // 假设有一个默认的运行模式
            git_commit_hash: String::new(),
            git_commit_time_utc: String::new(),
            rust_version_build: String::new(),
            rust_version_supported_min: String::new(),
            package_os: String::new(),
            package_time_utc: String::new(),
            local_db_path: "./data".to_string(),
            log_dir: "./logs".to_string(),
        }
    }

    pub fn new(name: &str, bundle_id: &str, description: &str, run_mode: rs_box::RunMode) -> Self {
        let mut a_app = Self::default();
        a_app.name = name.to_string();
        a_app.bundle_id = bundle_id.to_string();
        a_app.description = description.to_string();
        a_app.run_mode = run_mode;
        a_app
    }
}
