use std::fs;
use toml::{Value};
use crate::{config, utils};

pub const DEFAULT_WINDOW_ORIGIN_X: i32 = 0;
pub const DEFAULT_WINDOW_ORIGIN_Y: i32 = 0;
pub const DEFAULT_WINDOW_SIZE_WIDTH: i32 = 1440;
pub const DEFAULT_WINDOW_SIZE_HEIGHT: i32 = 900;

/// 项目名
const PROJECT_NAME: &str = "serverbox_gui";
/// 项目包名
const PROJECT_BUNDLE_ID: &str = "com.serverbox.serverbox_gui";
/// 项目版本
const PROJECT_VERSION: &str = "0.0.16";
/// 项目描述
const BUILD_MODE: rs_box::RunMode = rs_box::RunMode::RunModeDebug;
/// 项目描述
const PROJECT_DESCRIPTION: &str = "server box gui client";
/// Git提交hash
const GIT_COMMIT_HASH: &str = "0edfd7ce58ff486eea259128457ab4dc805e9217";

/// Git提交时间UTC
const GIT_COMMIT_TIME_UTC: &str = "2024-05-19_08:03:21_UTC";

/// 打包载体系统
const PACKAGE_OS: &str = "macos";

/// rust打包版本
const RUST_VERSION_BUILD: &str = "rustc 1.78.0 (9b00956e5 2024-04-29)";

/// rust最小支持版本
const RUST_VERSION_SUPPORTED_MIN: &str = "rust_1.60.0";
/// 打包时间UTC
const PACKAGE_TIME_UTC: &str = "2024-05-20_23:39:09_UTC";


// 使用lazy_static来创建一个全局的Mutex包裹的变量

fn get_project_config_with_cargo_toml(top_key: &str,sub_key: &str) -> String{
    // 尝试读取当前目录下的 Cargo.toml 文件
    let contents = match fs::read_to_string("Cargo.toml") {
        Ok(data) => data,
        Err(_e) => return "".to_string(),
    };

    // 解析 TOML 内容
    let parsed = match contents.parse::<Value>() {
        Ok(data) => data,
        Err(_e) => return "".to_string(),
    };

    // 尝试从解析后的 TOML 数据中获取项目名称
    let project_name = parsed
        .get(top_key)
        .and_then(|pkg| pkg.get(sub_key))
        .and_then(|v| v.as_str())
        .ok_or_else(|| "".to_string());

    project_name.unwrap().to_string()
}


pub fn load_default_app (){
    let mut current_app = config::app::DEFAULT_APP.lock().unwrap();

    current_app.name = PROJECT_NAME.to_string();
    current_app.bundle_id = PROJECT_BUNDLE_ID.to_string();
    current_app.description = PROJECT_DESCRIPTION.to_string();
    current_app.version = PROJECT_VERSION.to_string();

    current_app.run_mode = BUILD_MODE;

    current_app.git_commit_hash = GIT_COMMIT_HASH.to_string();
    current_app.git_commit_time_utc = GIT_COMMIT_TIME_UTC.to_string();
    current_app.package_os = PACKAGE_OS.to_string();
    current_app.rust_version_build = RUST_VERSION_BUILD.to_string();
    current_app.rust_version_supported_min = format!("rust {}",RUST_VERSION_SUPPORTED_MIN.to_string());
    current_app.package_time_utc = PACKAGE_TIME_UTC.to_string();

    if current_app.run_mode == rs_box::RunMode::RunModeDebug {
        let git_commit_hash = utils::cmds::execute_command("git show -s --format=%H");
        let git_commit_time = utils::cmds::execute_command(r#"git show -s --format=%ci | xargs -I{} date -u -j -f "%Y-%m-%d %H:%M:%S %z" "{}" +"%Y-%m-%d_%H:%M:%S_%Z""#);
        let package_os = std::env::consts::OS.to_string();
        let rust_version = utils::cmds::execute_command("rustc --version");
        let package_time = chrono::Utc::now().format("%Y-%m-%d_%H:%M:%S_%Z").to_string();
        let rust_min =  utils::cmds::execute_command(r#"echo $(grep rust-version ./Cargo.toml | awk -F '"' '{print $2}' | sed 's/\"//g')"#);

        current_app.git_commit_hash = git_commit_hash;
        current_app.git_commit_time_utc = git_commit_time;
        current_app.package_os = package_os;
        current_app.rust_version_build = rust_version;
        current_app.rust_version_supported_min = format!("rust {}",rust_min);
        current_app.package_time_utc = package_time;
    }
}
