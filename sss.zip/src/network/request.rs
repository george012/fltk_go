use std::str::FromStr;

use reqwest::Error;
use serde::{Deserialize, Serialize};


struct  Detail {}

#[derive(Serialize, Deserialize ,Debug)]
pub struct Metrics {
    cpu: Vec<Metric>
}

#[derive(Serialize, Deserialize ,Debug)]
pub struct Metric {
    name: String,
    desc: String,
    detail: CPU
}

#[derive(Serialize, Deserialize ,Debug)]
pub struct CPU {
    key: String,
    date: String,
    usage: f64
}

pub static BASE_URL: &str = "http://192.168.99.150:8090/api/v1/statistics/";

pub async fn make_request(key: &str) -> Result<Metrics, Error> {
    let mut url = String::from_str(BASE_URL).expect("read url error");
    url.push_str(key);
    // Make a GET request to a URL
    let response = reqwest::get(url)
        .await?
        .json::<Metrics>()
        .await?;

    // Print the response body
    println!("Response body: {:#?}", response);

    Ok(response)
}
