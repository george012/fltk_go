#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    #[tokio::main]
    fn test_get() {
        if let Err(err) = request::make_request("cpu").await {
            eprintln!("Error: {}", err);
        }
    }

}