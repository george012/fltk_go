#![allow(unused)]

use fltk::{app::screen_size, prelude::*, *};
use std::cell::RefCell;
use std::rc::Rc;

#[macro_use]
extern crate rust_i18n;
i18n!("locales");

use lazy_static::lazy_static;
use std::env;

mod config;
mod guis;
mod utils;
mod custom_cmds;
mod network;

fn draw_main_window() -> Rc<RefCell<fltk::window::Window>> {
    let (screen_width, screen_height) = screen_size();

    // 计算窗口居中的坐标
    let x = (screen_width - config::config::DEFAULT_WINDOW_SIZE_WIDTH as f64) / 2.00;
    let y = (screen_height - config::config::DEFAULT_WINDOW_SIZE_HEIGHT as f64) / 2.00;

    {
        let lang = *config::locales::DEFAULT_LANGUAGE.lock().unwrap();
        let a_title = config::locales::get_locales_value("app_name", lang);

        // 创建并返回窗口
        Rc::new(RefCell::new(fltk::window::Window::new(
            x as i32,
            y as i32,
            config::config::DEFAULT_WINDOW_SIZE_WIDTH,
            config::config::DEFAULT_WINDOW_SIZE_HEIGHT,
            a_title.as_str(),
        )))
    }
}

pub fn match_run_mode_from_str(s: &str) -> rs_box::RunMode {
    match s {
        "debug" => rs_box::RunMode::RunModeDebug,
        "test" => rs_box::RunMode::RunModeTest,
        "release" => rs_box::RunMode::RunModeRelease,
        _ => rs_box::RunMode::RunModeDebug, // 默认为 Debug
    }
}

fn setup_app() {
    config::config::load_default_app();

    let mut current_app = config::app::DEFAULT_APP.lock().unwrap();

    let args: Vec<String> = env::args().collect();

    custom_cmds::custom_cmds::handle_custom_cmds(args, &current_app);

    rs_box::rs_box_setup(
        current_app.name.as_str(),
        current_app.run_mode,
        current_app.log_dir.as_str(),
        7,
        30,
    );
}

#[cfg(target_os = "windows")]
extern crate winapi;

#[cfg(all(target_os = "windows", not(feature = "show_console")))]
use winapi::um::wincon::FreeConsole;

#[cfg(target_os = "windows")]
fn main() {
    if cfg!(not(feature = "show_console")) {
        unsafe {
            winapi::um::wincon::FreeConsole();
        }
    }
    // 你的 FLTK 程序代码
    setup_app();
    let main_app = app::App::default();
    let wind = draw_main_window();

    guis::guis::load_guis(wind.clone());

    wind.borrow_mut().end();
    wind.borrow_mut().show();

    main_app.run().unwrap();
}


#[tokio::main]
#[cfg(not(target_os = "windows"))]
async fn main() {
    // 你的 FLTK 程序代码
    setup_app();
    let main_app = app::App::default();
    let wind = draw_main_window();

    guis::guis::load_guis(wind.clone());

    wind.borrow_mut().end();
    wind.borrow_mut().show();

    let result = network::request::make_request("cpu").await;
    match result {
        Ok(m) => {println!("request body: {:#?}", m)},
        Err(err) => {eprint!("request error: {}", err);}
    }

    main_app.run().unwrap();
}
