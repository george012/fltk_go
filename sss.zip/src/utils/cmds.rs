use std::process::Command;

pub fn execute_command(command: &str) -> String {
    #[cfg(target_os = "windows")]
    {
        let output = Command::new("cmd")
            .args(&["/C", command])
            .output()
            .expect("Failed to execute command");

        std::str::from_utf8(&output.stdout)
            .unwrap()
            .trim()
            .to_string()
    }

    #[cfg(not(target_os = "windows"))]
    {
        let output = Command::new("sh")
            .arg("-c")
            .arg(command)
            .output()
            .expect("Failed to execute command");

        std::str::from_utf8(&output.stdout)
            .unwrap()
            .trim()
            .to_string()
    }
}