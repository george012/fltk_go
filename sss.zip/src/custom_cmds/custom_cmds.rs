use std::process;
use crate::config;


fn version_action(app: &config::app::App) {
    println!("名        字:  {}", app.name);
    println!("包        名:  {}", app.bundle_id);
    println!("版        本:  {}", app.version);
    println!("描        述:  {}", app.description);
    println!("打 包 模 式 :  {}", app.run_mode.to_string());

    if app.git_commit_hash.len() > 0 {
        println!("Git提交 Hash:  {}", &app.git_commit_hash[..10]);
    } else {
        println!("Git提交 Hash:  {}", app.git_commit_hash);
    }

    println!("Git 提 交 时 间:  {}", app.git_commit_time_utc);
    println!("构建 语言及版本 :  {}", app.rust_version_build);
    println!("语言最小支持版本:  {}", app.rust_version_supported_min);
    println!("构  建  系  统 :  {}", app.package_os);
    println!("构  建  时  间 :  {}", app.package_time_utc);
}

pub fn handle_custom_cmds(args: Vec<String>, s_app: &config::app::App) {
    if args.len() <= 1 {
        return;
    }

    let a_flag = &args[1];
    match a_flag.as_str() {
        "version" => version_action(s_app),
        _ => {
            eprintln!("not allow cmd");
            process::exit(1);
        }
    }
    process::exit(0);
}
