use std::env;

fn main() {
    // TODO 修改默认值 使其 支持是否显示 默认终端  默认 false 为不显示
    let show_console = env::var("SHOW_CONSOLE").unwrap_or_else(|_| "false".to_string());

    if show_console == "false" {
        println!("cargo:rustc-cfg=without_console");
    } else {
        println!("cargo:rustc-cfg=with_console");
    }

    cc::Build::new()
        .file("src/hello.c")
        .compile("hello");
}
