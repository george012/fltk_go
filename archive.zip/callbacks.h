#pragma once

#ifdef __cplusplus
extern "C" {
#endif

typedef struct Fl_Widget Fl_Widget;

extern void callback_handler(Fl_Widget *w, void* data);

#ifdef __cplusplus
}
#endif
  
