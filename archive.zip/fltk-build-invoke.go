package fltk_go

//go:generate go run fltk-build.go
