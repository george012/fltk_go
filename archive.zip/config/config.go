package config

const (
	ProjectName    = "fltk_go"
	ProjectVersion = "v0.0.26"
)
